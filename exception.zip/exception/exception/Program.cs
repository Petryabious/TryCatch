﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exception
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите первое число диапозона: ");
            string a = Console.ReadLine();
            Console.Write("Введите второе число диапозона: ");
            string b = Console.ReadLine();
            
            if (!(double.TryParse(a, out double x) && double.TryParse(b, out double y)))
            {
                Console.WriteLine("Некорректно введено значение ");
            }
            else
            {
                try
                {
                    if (y == 0.0 && x == 0.0)
                    {
                        throw new Exception("Error, два числа равны 0");
                    }
                    Console.WriteLine("Текущая функция 1+e**x");
                    for (double i = Math.Min(x,y); i < Math.Max(x,y); i+=0.1)
                    {
                       
                       
                        Console.WriteLine("Результат функции 1+e**{0} = {1:0.00}",i, 1 + Math.Pow(Math.E, i));

                    }
                }
                catch (Exception ex)
                {

                    Console.WriteLine(ex.Message);
                }
            }

            Console.ReadLine();

        }
    }
}
